

<?php $__env->startSection('content'); ?>
    <div class="flex-center position-relative content-margin">
        <div class="circle"></div>
            <div class="index-title">
            <h2><?php echo app('translator')->get('profile.saved'); ?></h2><br>
            <a href="<?php echo e(url('home')); ?>" class="blue-link"><?php echo app('translator')->get('checkout.navigate'); ?></a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\emanu\Documents\Kuliah\SEMESTER 5\UAS\webprog\Amazing_E_Grocery\resources\views/update_profile_success.blade.php ENDPATH**/ ?>