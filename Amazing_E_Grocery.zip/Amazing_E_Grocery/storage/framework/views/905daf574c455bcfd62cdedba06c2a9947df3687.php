<?php if(!Auth::user()): ?>
    <div class="nav_account_action">
        <a href="<?php echo e(url('register')); ?>"><?php echo app('translator')->get('navbar.register'); ?></a>
        <a href="<?php echo e(url('login')); ?>"><?php echo app('translator')->get('navbar.login'); ?></a>
    </div> 
<?php else: ?>
    <div class="nav_account_action" style="top: 30px;">
        <a href="<?php echo e(url('logout')); ?>" style="padding: 0 !important;"><?php echo app('translator')->get('navbar.logout'); ?></a>
    </div>
<?php endif; ?><?php /**PATH C:\Users\emanu\Documents\Kuliah\SEMESTER 5\UAS\webprog\Amazing_E_Grocery\resources\views/navbar_account_action.blade.php ENDPATH**/ ?>