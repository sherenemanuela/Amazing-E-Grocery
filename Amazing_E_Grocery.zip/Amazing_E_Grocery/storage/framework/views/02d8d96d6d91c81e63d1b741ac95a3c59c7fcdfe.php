

<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('maintenance.title'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class=" content-margin flex-column-center">
        <table class="user-table">
            <tr>
                <th><u><p><?php echo app('translator')->get('maintenance.account'); ?></p></u></th>
                <th><u><?php echo app('translator')->get('maintenance.action'); ?></u></th>
            </tr>
            <tr></tr>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($u->first_name); ?> <?php echo e($u->last_name); ?> - <?php echo ucfirst(trans($u->role()->first()->role_name)); ?></td>
                <td>
                    <a href="<?php echo e(url('/update-role-'.$u->account_id)); ?>" class="blue-link" style="margin-right: 40px;"><?php echo app('translator')->get('maintenance.update'); ?></a>
                    <a href="<?php echo e(url('/delete-'.$u->account_id)); ?>" class="blue-link"><?php echo app('translator')->get('maintenance.delete'); ?></a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\emanu\Documents\Kuliah\SEMESTER 5\UAS\webprog\Amazing_E_Grocery\resources\views/account_maintenance.blade.php ENDPATH**/ ?>