

<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('navbar.logout'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar_account_action'); ?>
    <?php echo $__env->make('navbar_account_action', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex-center position-relative content-margin">
        <div class="circle"></div>
        <h2 class="index-title"><?php echo app('translator')->get('login.logout_success'); ?></h2>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\emanu\Documents\Kuliah\SEMESTER 5\UAS\webprog\Amazing_E_Grocery\resources\views/logout.blade.php ENDPATH**/ ?>