<div class="nav_user_action">
    <a href="<?php echo e(url('home')); ?>"><?php echo app('translator')->get('navbar.home'); ?></a>
    <a href="<?php echo e(url('cart')); ?>"><?php echo app('translator')->get('navbar.cart'); ?></a>
    <a href="<?php echo e(url('profile')); ?>"><?php echo app('translator')->get('navbar.profile'); ?></a>
    <?php if(Auth::user()->role->role_name == 'admin'): ?>
        <a href="<?php echo e(url('account-maintenance')); ?>"><?php echo app('translator')->get('navbar.account_maintenance'); ?></a>
    <?php endif; ?>
</div><?php /**PATH C:\Users\emanu\Documents\Kuliah\SEMESTER 5\UAS\webprog\Amazing_E_Grocery\resources\views/navbar_action.blade.php ENDPATH**/ ?>