

<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('maintenance.update'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h5 style="margin: 50px 0;"><u><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></u></h5>
    <form action="/update-role-<?php echo e($user->account_id); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <table>
            <tr>
                <td><p><?php echo app('translator')->get('register.role'); ?>:</p></td>
                <td>
                    <select name="role" id="role">
                        <?php if($user->role->role_name == 'admin'): ?>
                            <option value="admin" selected>Admin</option>
                            <option value="user">User</option>
                        <?php else: ?>
                            <option value="admin">Admin</option>
                            <option value="user" selected>User</option>
                        <?php endif; ?>
                    </select>
                </td>
            </tr>
        </table>
        <input type="submit" class="submit" value="<?php echo app('translator')->get('profile.save'); ?>">
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\emanu\Documents\Kuliah\SEMESTER 5\UAS\webprog\Amazing_E_Grocery\resources\views/update_role.blade.php ENDPATH**/ ?>