

<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('cart.title'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container" style="padding: 50px 0;">
        <?php ($sum = 0); ?>
        <h3 style="margin-bottom: 60px;"><u><?php echo app('translator')->get('cart.cart'); ?></u></h3>
        <table class="flex-center">
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="cart-row">
                    <td>
                        <div style="width: 120px;">
                            <img src="<?php echo e($i->items->first()->image); ?>" style="width: 100%;">
                        </div>
                    </td>
                    <td><?php echo e($i->items->first()->item_name); ?></td>
                    <td>Rp. <?php echo number_format($i->price,0); ?>,-</td>
                    <td><a href="<?php echo e(url('/removeFromCart-'.$i->order_id)); ?>" class="blue-link"><?php echo app('translator')->get('cart.delete'); ?></a></td>
                </tr>
                <?php ($sum += $i->price); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <div class="d-flex justify-content-end">
            <h4 style="margin-right: 50px;"><?php echo app('translator')->get('cart.total'); ?>: Rp. <?php echo number_format($sum,0); ?>,-</h4>
            <a href="<?php echo e(url('/checkout' )); ?>">
                <button class="custom-button"><?php echo app('translator')->get('cart.checkout'); ?></button>
            </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\emanu\Documents\Kuliah\SEMESTER 5\UAS\webprog\Amazing_E_Grocery\resources\views/cart.blade.php ENDPATH**/ ?>