

<?php $__env->startSection('content'); ?>
    <div class="item-grid container">
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item-card flex-column-center">
                <img src="<?php echo e($i->image); ?>" style="width: 50%;">
                <p><?php echo e($i->item_name); ?></p>
                <a href="item-<?php echo e($i->item_id); ?>" class="blue-link"><?php echo app('translator')->get('home.detail'); ?></a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="flex-center pagination-sm" style="margin: 20px;">
        <?php echo e($items->links('pagination::bootstrap-4')); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\emanu\Documents\Kuliah\SEMESTER 5\UAS\webprog\Amazing_E_Grocery\resources\views/home.blade.php ENDPATH**/ ?>