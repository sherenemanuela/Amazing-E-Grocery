

<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('profile.profile'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container content-margin d-flex">
    <div style="width: 250px; height: 350px; margin: 50px 40px 0 0;">
        <img src="<?php echo e(Storage::url("profile_picture/".Auth::user()->display_picture_link)); ?>" style="width: 100%; height: 100%;">
    </div>
    <form action="/update-profile" method="POST" enctype="multipart/form-data" class="flex-column-center" style="margin: auto;">
        <?php echo csrf_field(); ?>
        <table>
            <tr>
                <td><p><?php echo app('translator')->get('register.first_name'); ?>:</p></td>
                <td>
                    <input type="text" id="first_name" name="first_name" value="<?php echo e(Auth::user()->first_name); ?>">
                    <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="error-msg"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </td>
                <td><p><?php echo app('translator')->get('register.last_name'); ?>:</p></td>
                <td>
                    <input type="text" id="last_name" name="last_name" value="<?php echo e(Auth::user()->last_name); ?>">
                    <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="error-msg"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </td>
            </tr>
            <tr>
                <td><p><?php echo app('translator')->get('register.email'); ?>:</p></td>
                <td>
                    <input type="text" id="email" name="email" value="<?php echo e(Auth::user()->email); ?>">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="error-msg"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </td>
                <td><p><?php echo app('translator')->get('register.role'); ?>:</p></td>
                <td>
                    <select name="role" id="role" disabled>
                        <?php if(Auth::user()->role == 'admin'): ?>
                            <option value="admin" selected>Admin</option>
                        <?php else: ?>
                            <option value="user" selected>User</option>
                        <?php endif; ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td><p><?php echo app('translator')->get('register.gender'); ?>:</p></td>
                <td>
                    <?php if(Auth::user()->gender == 'male'): ?>
                        <input checked type="radio" id="male" name="gender" value="male" style="width: 15px;">
                        <label for="male" style="margin-right: 30px;"><?php echo app('translator')->get('register.male'); ?></label>
                        <input type="radio" id="female" name="gender" value="female" style="width: 15px;">
                        <label for="female"><?php echo app('translator')->get('register.female'); ?></label>
                    <?php else: ?>
                        <input type="radio" id="male" name="gender" value="male" style="width: 15px;">
                        <label for="male" style="margin-right: 30px;"><?php echo app('translator')->get('register.male'); ?></label>
                        <input checked type="radio" id="female" name="gender" value="female" style="width: 15px;">
                        <label for="female"><?php echo app('translator')->get('register.female'); ?></label>
                    <?php endif; ?>
                </td>
                <td><p><?php echo app('translator')->get('register.display_picture'); ?>:</p></td>
                <td>
                    <input type="file" id="display_picture" name="display_picture">
                    <?php $__errorArgs = ['display_picture'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="error-msg"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </td>
            </tr>
            <tr>
                <td><p><?php echo app('translator')->get('register.password'); ?>:</p></td>
                <td>
                    <input type="password" id="password" name="password">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="error-msg"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </td>
                <td><p><?php echo app('translator')->get('register.confirm_password'); ?>:</p></td>
                <td>
                    <input type="password" id="password_confirmation" name="password_confirmation">
                    <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="error-msg"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </td>
            </tr>
        </table>
        <input type="submit" class="submit" value="<?php echo app('translator')->get('profile.save'); ?>">
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\emanu\Documents\Kuliah\SEMESTER 5\UAS\webprog\Amazing_E_Grocery\resources\views/profile.blade.php ENDPATH**/ ?>