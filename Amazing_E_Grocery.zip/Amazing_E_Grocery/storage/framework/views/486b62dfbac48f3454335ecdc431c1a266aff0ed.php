

<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('login.title'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container content-margin">
        <form action="/login" method="POST" class="flex-column-center" style="width: fit-content; margin: auto;">
            <?php echo csrf_field(); ?>
            <h2 style="align-self: flex-start; margin-bottom: 30px;"><u><?php echo app('translator')->get('login.login'); ?></u></h2>
            <table>
                <tr>
                    <td><p><?php echo app('translator')->get('login.email'); ?>:</p></td>
                    <td>
                        <input type="text" id="email" name="email">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="error-msg"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td><p><?php echo app('translator')->get('login.password'); ?>:</p></td>
                    <td>
                        <input type="password" id="password" name="password">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="error-msg"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
            </table>
            <input type="submit" class="submit" value="<?php echo app('translator')->get('login.submit'); ?>">
            <a href="<?php echo e(url('register')); ?>" style="color: blue !important; text-decoration: underline;"><?php echo app('translator')->get('login.navigate'); ?></a>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\emanu\Documents\Kuliah\SEMESTER 5\UAS\webprog\Amazing_E_Grocery\resources\views/login.blade.php ENDPATH**/ ?>