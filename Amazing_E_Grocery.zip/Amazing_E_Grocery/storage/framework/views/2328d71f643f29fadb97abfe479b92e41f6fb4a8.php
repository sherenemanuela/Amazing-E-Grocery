

<?php $__env->startSection('content'); ?>
<div class="container flex-column-center" style="margin-top: 50px; width: 80%;">
    <div class="justify-content-between d-flex">
        <div class="flex-column-center" style="width: 20%;">
            <h3><u><?php echo e($item->item_name); ?></u></h3>
            <img src="<?php echo e($item->image); ?>" style="width: 80%; margin-top: 50px;">
        </div>
        <div style="width: 70%; margin: 100px 0 40px 0;">
            <p><strong><?php echo app('translator')->get('detail.price'); ?>: Rp. <?php echo number_format($item->price,0); ?>,-</strong></p>
            <br>
            <p><?php echo $item->item_desc; ?></p>
        </div>
    </div>

    <a href="<?php echo e(url('addToCart-' . $item->item_id)); ?>" style="align-self: flex-end;">
        <button class="custom-button"><?php echo app('translator')->get('detail.buy'); ?></button>
    </a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\emanu\Documents\Kuliah\SEMESTER 5\UAS\webprog\Amazing_E_Grocery\resources\views/item_detail.blade.php ENDPATH**/ ?>