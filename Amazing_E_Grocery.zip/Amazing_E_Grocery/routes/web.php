<?php

use App\Http\Controllers\AccountMaintenanceController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\IndexController;
use App\Http\Controllers\ItemDetailController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\RegisterController;
use Illuminate\Contracts\Session\Session;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/en', [IndexController::class, 'indexPageEn']);
Route::get('/id', [IndexController::class, 'indexPageId']);
Route::get('/register', [RegisterController::class, 'registerPage']);
Route::post('/register', [RegisterController::class, 'register']);
Route::get('/login', [LoginController::class, 'loginPage']);
Route::post('/login', [LoginController::class, 'login']);

Route::middleware('user')->group(function(){
    Route::get('/home', [HomeController::class, 'homePage']);
    Route::get('/item-{id}', [ItemDetailController::class, 'itemDetailPage']);
    Route::get('/addToCart-{id}', [ItemDetailController::class, 'addToCart']);
    Route::get('/cart', [CartController::class, 'cartPage']);
    Route::get('/removeFromCart-{id}', [CartController::class, 'removeFromCart']);
    Route::get('/checkout', [CartController::class, 'checkout']);
    Route::get('/checkout-success', [CartController::class, 'checkoutSuccessPage']);
    Route::get('/profile', [ProfileController::class, 'profilePage']);
    Route::post('/update-profile', [ProfileController::class, 'updateProfile']);
    Route::get('/update-profile-success', [ProfileController::class, 'updateProfileSuccessPage']);
    Route::get('/logout', [LoginController::class, 'logout']);
    Route::get('/logout-page', [LoginController::class, 'logoutPage']);
});

Route::middleware('admin')->group(function(){
    Route::get('/account-maintenance', [AccountMaintenanceController::class, 'accountMaintenancePage']);
    Route::get('/update-role-{id}', [AccountMaintenanceController::class, 'updateRolePage']);
    Route::post('/update-role-{id}', [AccountMaintenanceController::class, 'updateRole']);
    Route::get('/delete-{id}', [AccountMaintenanceController::class, 'delete']);
});

