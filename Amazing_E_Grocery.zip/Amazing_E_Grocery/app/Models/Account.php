<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Account extends Authenticatable
{
    use HasFactory;
    protected $primaryKey = 'account_id';
    protected $fillable = ['first_name', 'last_name', 'display_picture_link', 'password', 'email', 'role_id', 'gender_id'];
    protected $guarded = ['role_id', 'gender_id'];
    protected $hidden = ['password', 'remember_token'];

    public function role(){
        return $this->hasOne(Role::class, 'role_id', 'role_id');
    }

    public function gender(){
        return $this->hasOne(Gender::class, 'gender_id', 'gender_id');
    }

    public function orders(){
        return $this->hasMany(Order::class, 'account_id', 'account_id');
    }
}
