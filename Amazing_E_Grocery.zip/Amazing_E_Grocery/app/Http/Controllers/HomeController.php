<?php

namespace App\Http\Controllers;

use App\Models\Item;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class HomeController extends Controller
{
    public function homePage(){
        App::setLocale(Session::get('language'));
        return view('home', ['items' => $this->getItems()]);
    }

    public function getItems(){
        return DB::table('items')->paginate(10);
    }
}
