<?php

namespace App\Http\Controllers;

use App\Models\Account;
use App\Models\Gender;
use App\Models\Role;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Storage;

class AccountMaintenanceController extends Controller
{
    public function accountMaintenancePage(){
        App::setLocale(Session::get('language'));
        return view('account_maintenance', ['users' => $this->getUsers()]);
    }

    public function getUsers(){
        return Account::all();
    }

    public function findUser($id){
        return Account::find($id);
    }

    public function updateRolePage($id){
        App::setLocale(Session::get('language'));
        return view('update_role', ['user' => $this->findUser($id)]);
    }

    public function updateRole($id, Request $request){
        $this->findUser($id)->role()->update([
            'role_name' => $request->role
        ]);
        return redirect('/account-maintenance');
    }

    public function delete($id){
        $account = $this->findUser($id);
        Storage::delete('public/profile_picture/'.$account->display_picture_link);
        Role::where('role_id', $account->role_id)->delete();
        Gender::where('gender_id', $account->gender_id)->delete();
        Account::where('account_id', $id)->delete();
        return redirect('/account-maintenance');
    }
}
