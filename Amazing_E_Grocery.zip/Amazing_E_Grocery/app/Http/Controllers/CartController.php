<?php

namespace App\Http\Controllers;

use App\Models\Item;
use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;

class CartController extends Controller
{
    public function cartPage(){
        App::setLocale(Session::get('language'));
        return view('cart', ['items' => $this->getCart()]);
    }

    public function getCart(){
        return Order::where([['checkout', false],['account_id', Auth::user()->account_id]])->get();
    }

    public function removeFromCart($id){
        Order::destroy($id);
        return redirect('/cart');
    }

    public function checkout(){
        Order::where('checkout', 0)->update(['checkout' => 1]);
        return redirect('/checkout-success');
    }

    public function checkoutSuccessPage(){
        App::setLocale(Session::get('language'));
        return view('checkout_success');
    }
}
