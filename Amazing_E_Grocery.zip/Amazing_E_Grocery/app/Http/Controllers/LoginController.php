<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\MessageBag;

class LoginController extends Controller
{
    public function loginPage(){
        App::setlocale(Session::get('language'));
        return view('login');
    }

    public function login(Request $request){
        $this->validate($request, [
            'email' => 'required | email',
            'password' => 'required',
        ]);

        $credentials = [
            'email' => $request->email,
            'password' => $request->password
        ];

        if(Auth::attempt($credentials, true)){
            Session::put('session', $credentials);
            if(Auth::user()->role == 'admin'){
                return redirect('/home');
            }else{
                return redirect('/home');
            }
        }

        $error = new MessageBag(['password' => ['Wrong Email/Password. Please Check Again']]);
        return redirect()->back()->withErrors($error);
    }

    public function logout(){
        $lang = Session::get('language');
        Session::flush();
        Auth::logout();
        Session::put('language', $lang);
        return redirect('/logout-page');
    }

    public function logoutPage(){
        App::setlocale(Session::get('language'));
        return view('logout');
    }
}
