<?php

namespace App\Http\Controllers;

use App\Models\Item;
use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class ItemDetailController extends Controller
{
    public function itemDetailPage($id){
        App::setLocale(Session::get('language'));
        return view('item_detail', ['item' => $this->getItem($id)]);
    }

    public function getItem($id){
        return Item::find($id);
    }

    public function addToCart($id){
        if(sizeof(Order::where([['item_id', $id], ['checkout', 0]])->get()) == 0)
            Order::create([
                'account_id' => Auth::user()->account_id,
                'item_id' => $id,
                'price' => $this->getItem($id)->price,
                'checkout' => 0
            ]);
        return redirect('/cart');
    }
}
