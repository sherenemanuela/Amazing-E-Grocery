<?php

namespace App\Http\Controllers;

use App\Models\Account;
use App\Models\Gender;
use App\Models\Role;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Storage;

class RegisterController extends Controller
{
    public function registerPage(){
        App::setlocale(Session::get('language'));
        return view('register');
    }

    public function register(Request $request){
        $this->validate($request, [
            'first_name' => 'required | max:25 | regex:/[a-zA-Z0-9]+$/',
            'last_name' => 'required | max:25 | regex:/[a-zA-Z0-9]+$/',
            'email' => 'required | unique:accounts,email| email',
            'gender' => 'required',
            'display_picture' => 'mimes:jpeg,jpg,png | required',
            'password' => 'required | min:8 | regex:/([0-9])/',
            'password_confirmation' => 'required | regex:/([0-9])/ | min:8 | same:password'
        ],[
            'first_name.max' => 'Must have less than 25 characters!',
            'first_name.regex' => 'Name cannot contain symbols!',
            'last_name.max' => 'Must have less than 25 characters!',
            'last_name.regex' => 'Name cannot contain symbols!',
            'email.unique' => 'Email already exist',
            'email.email' => 'Must be in email format!',
            'display_picture.mimes' => 'Must be in jpeg, jpg, png!',
            'password.min' => 'Password must have at least 8 characters!',
            'password.regex' => 'Password must contain a number!'
        ]);

        $picture_filename = $request->file('display_picture')->getClientOriginalName();
        Storage::putFileAs('public/profile_picture', $request->file('display_picture'), $picture_filename);

        $gender_id = Gender::create(['gender_desc' => $request->gender])->gender_id;
        $role_id = Role::create(['role_name' => $request->role])->role_id;
        
        Account::create([
            'first_name' => $request['first_name'],
            'last_name' => $request['last_name'],
            'display_picture_link' => $picture_filename,
            'password' => bcrypt($request->password),
            'role_id' => $role_id,
            'gender_id' => $gender_id,
            'email' => $request->email
        ]);

        return redirect('login');
    }
}
