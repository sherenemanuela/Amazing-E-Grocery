<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Session;

class IndexController extends Controller
{
    public function indexPageEn(){
        Session::put('language', 'en');
        App::setlocale(Session::get('language'));
        return view('index');
    }

    public function indexPageId(){
        Session::put('language', 'id');
        App::setlocale(Session::get('language'));
        return view('index');
    }
}
