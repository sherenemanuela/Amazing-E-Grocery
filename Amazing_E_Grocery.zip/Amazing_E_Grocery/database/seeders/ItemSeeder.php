<?php

namespace Database\Seeders;

use Carbon\Carbon;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ItemSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('items')->insert([
            [
                'item_name' => 'Lettuce',
                'item_desc' => 'LIMITED LETTUCE!<br/><br/>Lettuce is an annual plant of the family Asteraceae. Lettuce is most often used for salads, although it is also seen in other kinds of food, such as soups, sandwiches and wraps; it can also be grilled. <br/><br/>Notes: This lettuce won 1st place at Canna UK National Excellent Lettuce Championship',
                'price' => 800000,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'image' => 'https://cdn-icons-png.flaticon.com/512/135/135715.png'
            ],
            [
                'item_name' => 'Spinach',
                'item_desc' => 'LIMITED SPINACH!<br/><br/>Spinach is a leafy green flowering plant native to central and western Asia.<br/><br/>Notes: This spinach was the reward of Popeye\'s Championship',
                'price' => 500000,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'image' => 'https://cdn-icons-png.flaticon.com/512/2503/2503919.png'
            ],
            [
                'item_name' => 'Tomato',
                'item_desc' => 'LIMITED TOMATO!<br/><br/>The tomato is the edible berry of the plant Solanum lycopersicum, commonly known as the tomato plant.<br/><br/>Notes: This tomato won 2nd place at The Harvest Festival 2023',
                'price' => 100000,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'image' => 'https://cdn-icons-png.flaticon.com/512/2503/2503930.png'
            ],
            [
                'item_name' => 'Eggplant',
                'item_desc' => 'LIMITED EGGPLANT!<br/><br/>Typically used as a vegetable in cooking, it is a berry by botanical definition. This eggplant is the only one in the world because of its unique shape.<br/><br/>Notes: This eggplant was planted by Bill Gates',
                'price' => 850000,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'image' => 'https://cdn-icons-png.flaticon.com/512/8930/8930973.png'
            ],
            [
                'item_name' => 'Corn',
                'item_desc' => 'LIMITED CORN!<br/><br/>Corn is a cereal grain first domesticated by indigenous peoples in southern Mexico about 10,000 years ago.<br/><br/>Notes: This corn was preserved from 1000 years ago.',
                'price' => 10000000,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'image' => 'https://cdn-icons-png.flaticon.com/512/1614/1614263.png'
            ],
            [
                'item_name' => 'Milk',
                'item_desc' => 'LIMITED MILK!<br/><br/>Milk is a nutrient-dense food consisting of varying amounts of carbohydrate, fat, and protein. This limited milk is only produced once every 10 years.<br/><br/>Notes: This milk is the last batch ever.',
                'price' => 900000,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'image' => 'https://cdn-icons-png.flaticon.com/512/2049/2049100.png'
            ],
            [
                'item_name' => 'Cheese',
                'item_desc' => 'LIMITED CHEESE!<br/><br/>Cheese is a dairy product produced in wide ranges of flavors, textures, and forms by coagulation of the milk protein casein.<br/><br/>Notes: This cheese was the first cheese produced by the famous cheese maker.',
                'price' => 5000000,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'image' => 'https://cdn-icons-png.flaticon.com/512/4063/4063291.png'
            ],
            [
                'item_name' => 'Bread',
                'item_desc' => 'LIMITED BREAD!<br/><br/>Bread is a staple food prepared from a dough of flour and water, usually by baking. Throughout recorded history and around the world, it has been an important part of many cultures\' diet.<br/><br/>Notes: This bread won 1st place at World Bread Championship',
                'price' => 300000,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'image' => 'https://cdn-icons-png.flaticon.com/512/3348/3348078.png'
            ],
            [
                'item_name' => 'Vinegar',
                'item_desc' => 'LIMITED VINEGAR!<br/><br/>Vinegar is an aqueous solution of acetic acid and trace compounds that may include flavorings.<br/><br/>Notes: This vinegar was produced by the famous vinegar critic',
                'price' => 200000,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'image' => 'https://cdn-icons-png.flaticon.com/512/1919/1919622.png'
            ],
            [
                'item_name' => 'Watermelon',
                'item_desc' => 'LIMITED WATERMELON!<br/><br/>Watermelon is a flowering plant species of the Cucurbitaceae family and the name of its edible fruit. A scrambling and trailing vine-like plant, it is a highly cultivated fruit worldwide, with more than 1,000 varieties.<br/><br/>Notes: This watermelon won 1st place at Canada Watermelon Championship',
                'price' => 1500000,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'image' => 'https://cdn-icons-png.flaticon.com/512/2224/2224249.png'
            ],
            [
                'item_name' => 'Apple',
                'item_desc' => 'LIMITED APPLE!<br/><br/>An apple is an edible fruit produced by an apple tree. Apple trees are cultivated worldwide and are the most widely grown species in the genus Malus. The tree originated in Central Asia, where its wild ancestor, Malus sieversii, is still found today.<br/><br/>Notes: This apple will never rot',
                'price' => 600000,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'image' => 'https://cdn-icons-png.flaticon.com/512/415/415733.png'
            ],
            [
                'item_name' => 'Banana',
                'item_desc' => 'LIMITED BANANA!<br/><br/>A banana is an elongated, edible fruit produced by several kinds of large herbaceous flowering plants in the genus Musa.<br/><br/>Notes: This banana originated from the lost city, Atlantis',
                'price' => 700000,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
                'image' => 'https://cdn-icons-png.flaticon.com/512/3143/3143645.png'
            ],
        ]);
    }
}
