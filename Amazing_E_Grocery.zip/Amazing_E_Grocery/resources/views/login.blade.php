@extends('template')

@section('title')
    @lang('login.title')
@endsection

@section('content')
    <div class="container content-margin">
        <form action="/login" method="POST" class="flex-column-center" style="width: fit-content; margin: auto;">
            @csrf
            <h2 style="align-self: flex-start; margin-bottom: 30px;"><u>@lang('login.login')</u></h2>
            <table>
                <tr>
                    <td><p>@lang('login.email'):</p></td>
                    <td>
                        <input type="text" id="email" name="email">
                        @error('email')
                            <p class="error-msg">{{$message}}</p>
                        @enderror
                    </td>
                </tr>
                <tr>
                    <td><p>@lang('login.password'):</p></td>
                    <td>
                        <input type="password" id="password" name="password">
                        @error('password')
                            <p class="error-msg">{{$message}}</p>
                        @enderror
                    </td>
                </tr>
            </table>
            <input type="submit" class="submit" value="@lang('login.submit')">
            <a href="{{ url('register') }}" style="color: blue !important; text-decoration: underline;">@lang('login.navigate')</a>
        </form>
    </div>
@endsection