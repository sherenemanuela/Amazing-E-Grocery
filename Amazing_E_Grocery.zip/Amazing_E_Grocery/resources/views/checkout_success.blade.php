@extends('template')

@section('title')
    @lang('checkout.title')
@endsection

@section('content')
    <div class="flex-center position-relative content-margin">
        <div class="circle"></div>
            <div class="index-title">
            <h2>@lang('checkout.success')</h2><br>
            <h5>@lang('checkout.subtitle')</h5><br>
            <a href="{{ url('home') }}" class="blue-link">@lang('checkout.navigate')</a>
        </div>
    </div>
@endsection

