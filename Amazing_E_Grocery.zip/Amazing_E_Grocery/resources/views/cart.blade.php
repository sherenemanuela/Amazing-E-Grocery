@extends('user_template')

@section('title')
    @lang('cart.title')
@endsection

@section('content')
    <div class="container" style="padding: 50px 0;">
        @php($sum = 0)
        <h3 style="margin-bottom: 60px;"><u>@lang('cart.cart')</u></h3>
        <table class="flex-center">
            @foreach($items as $i)
                <tr class="cart-row">
                    <td>
                        <div style="width: 120px;">
                            <img src="{{ $i->items->first()->image }}" style="width: 100%;">
                        </div>
                    </td>
                    <td>{{ $i->items->first()->item_name }}</td>
                    <td>@idr($i->price)</td>
                    <td><a href="{{ url('/removeFromCart-'.$i->order_id) }}" class="blue-link">@lang('cart.delete')</a></td>
                </tr>
                @php($sum += $i->price)
            @endforeach
        </table>
        <div class="d-flex justify-content-end">
            <h4 style="margin-right: 50px;">@lang('cart.total'): @idr($sum)</h4>
            <a href="{{ url('/checkout' )}}">
                <button class="custom-button">@lang('cart.checkout')</button>
            </a>
        </div>
    </div>
@endsection