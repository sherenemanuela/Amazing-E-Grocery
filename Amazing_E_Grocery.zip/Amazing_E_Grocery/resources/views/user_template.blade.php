@extends('template')

@section('navbar_account_action')
    @include('navbar_account_action')
@endsection

@section('navbar_action')
    @include('navbar_action')
@endsection