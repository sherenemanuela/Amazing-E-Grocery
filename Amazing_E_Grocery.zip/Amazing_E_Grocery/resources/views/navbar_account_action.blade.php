@if(!Auth::user())
    <div class="nav_account_action">
        <a href="{{ url('register') }}">@lang('navbar.register')</a>
        <a href="{{ url('login') }}">@lang('navbar.login')</a>
    </div> 
@else
    <div class="nav_account_action" style="top: 30px;">
        <a href="{{ url('logout') }}" style="padding: 0 !important;">@lang('navbar.logout')</a>
    </div>
@endif