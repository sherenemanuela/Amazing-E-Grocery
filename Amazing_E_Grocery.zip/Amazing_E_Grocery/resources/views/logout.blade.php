@extends('template')

@section('title')
    @lang('navbar.logout')
@endsection

@section('navbar_account_action')
    @include('navbar_account_action')
@endsection

@section('content')
    <div class="flex-center position-relative content-margin">
        <div class="circle"></div>
        <h2 class="index-title">@lang('login.logout_success')</h2>
    </div>
@endsection