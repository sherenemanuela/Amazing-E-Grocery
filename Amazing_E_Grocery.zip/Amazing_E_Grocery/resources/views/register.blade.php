@extends('template')

@section('title')
    @lang('register.title')
@endsection

@section('content')
    <div class="container content-margin">
        <form action="/register" method="POST" enctype="multipart/form-data" class="flex-column-center" style="width: fit-content; margin: auto;">
            @csrf
            <h2 style="align-self: flex-start; margin-bottom: 30px;"><u>@lang('register.register')</u></h2>
            <table>
                <tr>
                    <td><p>@lang('register.first_name'):</p></td>
                    <td>
                        <input type="text" id="first_name" name="first_name">
                        @error('first_name')
                            <p class="error-msg">{{$message}}</p>
                        @enderror
                    </td>
                    <td><p>@lang('register.last_name'):</p></td>
                    <td>
                        <input type="text" id="last_name" name="last_name">
                        @error('last_name')
                            <p class="error-msg">{{$message}}</p>
                        @enderror
                    </td>
                </tr>
                <tr>
                    <td><p>@lang('register.email'):</p></td>
                    <td>
                        <input type="text" id="email" name="email">
                        @error('email')
                            <p class="error-msg">{{$message}}</p>
                        @enderror
                    </td>
                    <td><p>@lang('register.role'):</p></td>
                    <td>
                        <select name="role" id="role">
                            <option value="admin" selected>Admin</option>
                            <option value="user">User</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td><p>@lang('register.gender'):</p></td>
                    <td>
                        <input checked type="radio" id="male" name="gender" value="male" style="width: 15px;">
                        <label for="male" style="margin-right: 30px;">Male</label>
                        <input type="radio" id="female" name="gender" value="female" style="width: 15px;">
                        <label for="female">Female</label>
                    </td>
                    <td><p>@lang('register.display_picture'):</p></td>
                    <td>
                        <input type="file" id="display_picture" name="display_picture">
                        @error('display_picture')
                            <p class="error-msg">{{$message}}</p>
                        @enderror
                    </td>
                </tr>
                <tr>
                    <td><p>@lang('register.password'):</p></td>
                    <td>
                        <input type="password" id="password" name="password">
                        @error('password')
                            <p class="error-msg">{{$message}}</p>
                        @enderror
                    </td>
                    <td><p>@lang('register.confirm_password'):</p></td>
                    <td>
                        <input type="password" id="password_confirmation" name="password_confirmation">
                        @error('password_confirmation')
                            <p class="error-msg">{{$message}}</p>
                        @enderror
                    </td>
                </tr>
            </table>
            <input type="submit" class="submit" value="@lang('register.submit')">
            <a href="{{ url('login') }}" style="color: blue !important; text-decoration: underline;">@lang('register.navigate')</a>
        </form>
    </div>
@endsection