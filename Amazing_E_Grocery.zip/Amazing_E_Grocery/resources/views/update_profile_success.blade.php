@extends('template')

@section('content')
    <div class="flex-center position-relative content-margin">
        <div class="circle"></div>
            <div class="index-title">
            <h2>@lang('profile.saved')</h2><br>
            <a href="{{ url('home') }}" class="blue-link">@lang('checkout.navigate')</a>
        </div>
    </div>
@endsection