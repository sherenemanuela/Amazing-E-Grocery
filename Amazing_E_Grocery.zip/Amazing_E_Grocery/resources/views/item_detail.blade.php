@extends('user_template')

@section('content')
<div class="container flex-column-center" style="margin-top: 50px; width: 80%;">
    <div class="justify-content-between d-flex">
        <div class="flex-column-center" style="width: 20%;">
            <h3><u>{{ $item->item_name }}</u></h3>
            <img src="{{ $item->image }}" style="width: 80%; margin-top: 50px;">
        </div>
        <div style="width: 70%; margin: 100px 0 40px 0;">
            <p><strong>@lang('detail.price'): @idr($item->price)</strong></p>
            <br>
            <p>{!! $item->item_desc !!}</p>
        </div>
    </div>

    <a href="{{ url('addToCart-' . $item->item_id) }}" style="align-self: flex-end;">
        <button class="custom-button">@lang('detail.buy')</button>
    </a>
</div>
@endsection