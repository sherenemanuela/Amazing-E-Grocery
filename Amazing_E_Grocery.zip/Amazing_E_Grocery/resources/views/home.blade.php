@extends('user_template')

@section('content')
    <div class="item-grid container">
        @foreach ($items as $i)
            <div class="item-card flex-column-center">
                <img src="{{ $i->image }}" style="width: 50%;">
                <p>{{ $i->item_name }}</p>
                <a href="item-{{ $i->item_id }}" class="blue-link">@lang('home.detail')</a>
            </div>
        @endforeach
    </div>
    <div class="flex-center pagination-sm" style="margin: 20px;">
        {{ $items->links('pagination::bootstrap-4') }}
    </div>
@endsection