@extends('template')

@section('title')
    @lang('index.title')
@endsection

@section('navbar_account_action')
    @include('navbar_account_action')
@endsection

@section('content')
    <div class="flex-center position-relative content-margin">
        <div class="circle"></div>
        <h2 class="index-title">@lang('index.index_title')</h2>
    </div>
@endsection