<div class="nav_user_action">
    <a href="{{ url('home') }}">@lang('navbar.home')</a>
    <a href="{{ url('cart') }}">@lang('navbar.cart')</a>
    <a href="{{ url('profile') }}">@lang('navbar.profile')</a>
    @if(Auth::user()->role->role_name == 'admin')
        <a href="{{ url('account-maintenance') }}">@lang('navbar.account_maintenance')</a>
    @endif
</div>