@extends('user_template')

@section('title')
    @lang('profile.profile')
@endsection

@section('content')
<div class="container content-margin d-flex">
    <div style="width: 250px; height: 350px; margin: 50px 40px 0 0;">
        <img src="{{ Storage::url("profile_picture/".Auth::user()->display_picture_link) }}" style="width: 100%; height: 100%;">
    </div>
    <form action="/update-profile" method="POST" enctype="multipart/form-data" class="flex-column-center" style="margin: auto;">
        @csrf
        <table>
            <tr>
                <td><p>@lang('register.first_name'):</p></td>
                <td>
                    <input type="text" id="first_name" name="first_name" value="{{ Auth::user()->first_name }}">
                    @error('first_name')
                        <p class="error-msg">{{$message}}</p>
                    @enderror
                </td>
                <td><p>@lang('register.last_name'):</p></td>
                <td>
                    <input type="text" id="last_name" name="last_name" value="{{ Auth::user()->last_name }}">
                    @error('last_name')
                        <p class="error-msg">{{$message}}</p>
                    @enderror
                </td>
            </tr>
            <tr>
                <td><p>@lang('register.email'):</p></td>
                <td>
                    <input type="text" id="email" name="email" value="{{ Auth::user()->email }}">
                    @error('email')
                        <p class="error-msg">{{$message}}</p>
                    @enderror
                </td>
                <td><p>@lang('register.role'):</p></td>
                <td>
                    <select name="role" id="role" disabled>
                        @if(Auth::user()->role == 'admin')
                            <option value="admin" selected>Admin</option>
                        @else
                            <option value="user" selected>User</option>
                        @endif
                    </select>
                </td>
            </tr>
            <tr>
                <td><p>@lang('register.gender'):</p></td>
                <td>
                    @if(Auth::user()->gender == 'male')
                        <input checked type="radio" id="male" name="gender" value="male" style="width: 15px;">
                        <label for="male" style="margin-right: 30px;">@lang('register.male')</label>
                        <input type="radio" id="female" name="gender" value="female" style="width: 15px;">
                        <label for="female">@lang('register.female')</label>
                    @else
                        <input type="radio" id="male" name="gender" value="male" style="width: 15px;">
                        <label for="male" style="margin-right: 30px;">@lang('register.male')</label>
                        <input checked type="radio" id="female" name="gender" value="female" style="width: 15px;">
                        <label for="female">@lang('register.female')</label>
                    @endif
                </td>
                <td><p>@lang('register.display_picture'):</p></td>
                <td>
                    <input type="file" id="display_picture" name="display_picture">
                    @error('display_picture')
                        <p class="error-msg">{{$message}}</p>
                    @enderror
                </td>
            </tr>
            <tr>
                <td><p>@lang('register.password'):</p></td>
                <td>
                    <input type="password" id="password" name="password">
                    @error('password')
                        <p class="error-msg">{{$message}}</p>
                    @enderror
                </td>
                <td><p>@lang('register.confirm_password'):</p></td>
                <td>
                    <input type="password" id="password_confirmation" name="password_confirmation">
                    @error('password_confirmation')
                        <p class="error-msg">{{$message}}</p>
                    @enderror
                </td>
            </tr>
        </table>
        <input type="submit" class="submit" value="@lang('profile.save')">
    </form>
</div>
@endsection