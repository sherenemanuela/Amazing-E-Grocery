@extends('user_template')

@section('title')
    @lang('maintenance.title')
@endsection

@section('content')
    <div class=" content-margin flex-column-center">
        <table class="user-table">
            <tr>
                <th><u><p>@lang('maintenance.account')</p></u></th>
                <th><u>@lang('maintenance.action')</u></th>
            </tr>
            <tr></tr>
            @foreach($users as $u)
            <tr>
                <td>{{ $u->first_name }} {{ $u->last_name}} - @first_capitalize($u->role()->first()->role_name)</td>
                <td>
                    <a href="{{ url('/update-role-'.$u->account_id) }}" class="blue-link" style="margin-right: 40px;">@lang('maintenance.update')</a>
                    <a href="{{ url('/delete-'.$u->account_id) }}" class="blue-link">@lang('maintenance.delete')</a>
                </td>
            </tr>
            @endforeach
        </table>
    </div>
@endsection