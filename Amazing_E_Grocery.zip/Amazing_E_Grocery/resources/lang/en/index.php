<?php

return[
    'index_title' => 'Find and Buy Your Grocery Here!',
    'title' => 'Index'
];