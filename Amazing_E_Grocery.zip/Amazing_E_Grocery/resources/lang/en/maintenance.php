<?php

return[
    'title' => 'Account Maintenance',
    'delete' => 'Delete',
    'update' => 'Update Role',
    'account' => 'Account',
    'action' => 'Action'
];