<?php
return[
    'title' => 'Home',
    'detail' => 'Detail'
];
