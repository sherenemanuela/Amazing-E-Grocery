<?php

return[
    'title' => 'Cart',
    'cart' => 'Cart',
    'total' => 'Total',
    'checkout' => 'Checkout',
    'delete' => 'Delete'
];