<?php

return [
    'title' => 'Login',
    'login' => 'Login',
    'email' => 'Email Address',
    'submit' => 'Submit',
    'navigate' => 'Don\'t have an account? click here to sign up',
    'password' => 'Password',
    'logout_success' => 'Logout Success!'
];