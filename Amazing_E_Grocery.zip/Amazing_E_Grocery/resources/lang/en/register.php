<?php

return[
    'title' => 'Register',
    'register' => 'Register',
    'first_name' => 'First Name',
    'last_name' => 'Last Name',
    'email' => 'Email',
    'role' => 'Role',
    'gender' => 'Gender',
    'display_picture' => 'Display Picture',
    'password' => 'Password',
    'confirm_password' => 'Confirm Password',
    'submit' => 'Submit',
    'navigate' => 'Already have an account? click here to login',
    'save' => 'Save',
    'profile' => 'Profile',
    'female' => 'Female',
    'male' => 'Male'
];