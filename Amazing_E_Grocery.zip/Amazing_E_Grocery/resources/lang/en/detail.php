<?php
return[
    'title' => 'Detail',
    'buy' => 'Buy',
    'price' => 'Price'
];