<?php

return[
    'title' => 'Checkout',
    'navigate' => 'Click here to "Home"',
    'subtitle' => 'We will contact you 1x24 hours.',
    'success' => 'Success!'
];