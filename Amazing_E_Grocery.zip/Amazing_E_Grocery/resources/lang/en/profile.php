<?php
return[
    'title' => 'Profile',
    'saved' => 'Saved',
    'save' => 'Save',
    'profile' => 'Profil',
];