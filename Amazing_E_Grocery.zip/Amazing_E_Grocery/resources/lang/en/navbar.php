<?php

return[
    'register' => 'Register',
    'login' => 'Login',
    'home' => 'Home',
    'cart' => 'Cart',
    'profile' => 'Profile',
    'account_maintenance' => 'Account Maintenance',
    'logout' => 'Logout',
    'url_register' => 'register'
];