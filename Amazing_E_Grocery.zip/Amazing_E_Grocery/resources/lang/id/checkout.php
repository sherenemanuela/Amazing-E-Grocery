<?php

return[
    'title' => 'Checkout',
    'navigate' => 'Klik disini ke "Beranda"',
    'subtitle' => 'Kami akan menghubungi anda 1x24 jam.',
    'success' => 'Sukses!'
];