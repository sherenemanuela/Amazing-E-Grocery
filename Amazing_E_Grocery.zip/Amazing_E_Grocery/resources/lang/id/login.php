<?php

return [
    'title' => 'Masuk',
    'login' => 'Masuk',
    'email' => 'Alamat Email',
    'submit' => 'Kirim',
    'navigate' => 'Belum punya akun? Klik disini untuk daftar',
    'password' => 'Kata Sandi',
    'logout_success' => 'Keluar Berhasil!'
];