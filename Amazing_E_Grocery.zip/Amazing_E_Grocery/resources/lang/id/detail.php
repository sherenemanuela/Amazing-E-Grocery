<?php
return[
    'title' => 'Rincian',
    'buy' => 'Beli',
    'price' => 'Harga'
];