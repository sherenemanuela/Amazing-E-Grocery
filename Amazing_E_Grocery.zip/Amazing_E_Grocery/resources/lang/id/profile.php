<?php
return[
    'title' => 'Profil',
    'saved' => 'Tersimpan',
    'save' => 'Simpan',
    'profile' => 'Profil',
];