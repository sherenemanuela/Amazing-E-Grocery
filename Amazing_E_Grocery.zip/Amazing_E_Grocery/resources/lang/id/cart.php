<?php

return[
    'title' => 'Keranjang',
    'cart' => 'Keranjang',
    'total' => 'Jumlah',
    'checkout' => 'Checkout',
    'delete' => 'Hapus'
];