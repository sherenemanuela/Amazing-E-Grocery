<?php

return[
    'register' => 'Daftar',
    'login' => 'Masuk',
    'home' => 'Beranda',
    'cart' => 'Keranjang',
    'profile' => 'Profil',
    'account_maintenance' => 'Pemeliharaan Akun',
    'logout' => 'Keluar',
    'url_register' => 'daftar'
];