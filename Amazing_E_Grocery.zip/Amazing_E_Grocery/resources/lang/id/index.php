<?php

return[
    'index_title' => 'Temukan dan Beli Barang Kebutuhan Anda Disini!',
    'title' => 'Halaman Utama'
];