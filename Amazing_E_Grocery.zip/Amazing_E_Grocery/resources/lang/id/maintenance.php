<?php

return[
    'title' => 'Pemeliharaan Akun',
    'delete' => 'Hapus',
    'update' => 'Ubah Peran',
    'account' => 'Akun',
    'action' => 'Tindakan'
];