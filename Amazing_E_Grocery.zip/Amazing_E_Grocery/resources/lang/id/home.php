<?php
return[
    'title' => 'Beranda',
    'detail' => 'Rincian'
];
