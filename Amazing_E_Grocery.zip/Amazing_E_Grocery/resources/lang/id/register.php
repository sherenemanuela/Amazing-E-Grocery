<?php

return[
    'title' => 'Daftar',
    'register' => 'Daftar',
    'first_name' => 'Nama Depan',
    'last_name' => 'Nama Belakang',
    'email' => 'Email',
    'role' => 'Peran',
    'gender' => 'Jenis Kelamin',
    'display_picture' => 'Foto Profil',
    'password' => 'Kata Sandi',
    'confirm_password' => 'Konfirmasi Kata Sandi',
    'submit' => 'Kirim',
    'navigate' => 'Sudah punya akun? Klik disini untuk masuk',
    'female' => 'Perempuan',
    'male' => 'Laki-laki'
];